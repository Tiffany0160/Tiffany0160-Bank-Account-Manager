package BankAccountManager;

import java.util.Scanner;

public class BankAccountManager {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double balance = 500.0;
        int choice;

        do {
            System.out.println("\n--- BANK MENU ---");
            System.out.println("1. Check Balance");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Exit");

            System.out.print("Choose option: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Balance: R" + balance);
                    break;

                case 2:
                    System.out.print("Enter deposit amount: ");
                    double deposit = sc.nextDouble();
                    balance += deposit;
                    System.out.println("Deposit successful");
                    break;

                case 3:
                    System.out.print("Enter withdraw amount: ");
                    double withdraw = sc.nextDouble();
                    if (withdraw <= balance) {
                        balance -= withdraw;
                        System.out.println("Withdraw successful");
                    } else {
                        System.out.println("Insufficient funds");
                    }
                    break;

                case 4:
                    System.out.println("Thank you for banking with us");
                    break;

                default:
                    System.out.println("Invalid option");
            }
        } while (choice != 4);

        sc.close();
    }
}
